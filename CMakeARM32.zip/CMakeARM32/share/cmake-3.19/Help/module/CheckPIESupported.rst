.. cmake-module:: ../../Modules/CheckPIESupported.cmake
