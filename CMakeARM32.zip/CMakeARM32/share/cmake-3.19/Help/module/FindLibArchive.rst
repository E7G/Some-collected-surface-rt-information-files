.. cmake-module:: ../../Modules/FindLibArchive.cmake
